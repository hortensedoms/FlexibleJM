#ifndef JMBAYES2SURV_H
#define JMBAYES2SURV_H

#include <Rcpp.h>
#include <RcppArmadillo.h>
#include "JMbayes2_Funs.h"
#include "JMbayes2_LogDens.h"
// [[Rcpp::depends("RcppArmadillo")]]

using namespace Rcpp;
using namespace arma;

double logPrior_surv (
  const vec &bs_gammas,const vec&gammas, const vec &gammasF1,const vec &alphas,
  const field<vec> &prior_mean_bs_gammas, field<mat> &prior_Tau_bs_gammas,
  const vec &tau_bs_gammas,
  const field<vec> &prior_mean_gammasF1, field<mat> &prior_Tau_gammasF1,
  const vec &tau_gammasF1,
  const vec &prior_mean_gammas, mat &prior_Tau_gammas, const vec &lambda_gammas,
  const double &tau_gammas, const bool &shrink_gammas,
  const vec &prior_mean_alphas, mat &prior_Tau_alphas, const vec &lambda_alphas,
  const double &tau_alphas, const bool &shrink_alphas,
  const bool &recurrent, const vec &alphaF, const vec prior_mean_alphaF,
  mat &prior_Tau_alphaF, const vec &lambda_alphaF, const double &tau_alphaF, 
  const bool &shrink_alphaF, const uword &it) {
  uword n_strata = prior_mean_bs_gammas.n_elem;
  uword n_per_stratum = bs_gammas.n_rows / n_strata;
  double out(0.0);
  for (uword i = 0; i < n_strata; ++i) {
    vec mu = prior_mean_bs_gammas.at(i);
      //    if(it<2){  std::cout  <<" logPrior Bs.gammas"  << std::endl;}

    out += logPrior(bs_gammas.rows(i * n_per_stratum, (i + 1) * n_per_stratum - 1),
                    mu, prior_Tau_bs_gammas.at(i), mu.ones(), tau_bs_gammas.at(i),
                    false, it);
  }

  //Partie Flexible - TO-DO : Vérifier si ca change qqlchose de faire les deux flexibles séparement ou si ca doit être fait en même temps comme pour gammas
  uword n_strataF1 = prior_mean_gammasF1.n_elem;
  uword n_per_stratumF1 = gammasF1.n_rows / n_strataF1;

  for (uword i = 0; i < n_strataF1; ++i) {
    vec mu = prior_mean_gammasF1.at(i);

      //   if(it<2){  std::cout  <<" logPrior gammasF1"  << std::endl;}

    out += logPrior(gammasF1.rows(i * n_per_stratumF1, (i + 1) * n_per_stratumF1 - 1),
                    mu, prior_Tau_gammasF1.at(i), mu.zeros(), tau_gammasF1.at(i),
                    false,it);
  }

  
  
       //  if(it<2){ std::cout  <<" logPrior gammas"  << std::endl;}
  out += logPrior(gammas, prior_mean_gammas, prior_Tau_gammas, lambda_gammas,
                  tau_gammas, shrink_gammas,it);
    //  if(it<2){  std::cout  <<" logPrior alphas"  << std::endl;}
  out += logPrior(alphas, prior_mean_alphas, prior_Tau_alphas, lambda_alphas,
                  tau_alphas, shrink_alphas,it);
  
  if (recurrent) {
    out += logPrior(alphaF, prior_mean_alphaF, prior_Tau_alphaF, lambda_alphaF,
                    tau_alphaF, shrink_alphaF,it);
  }
  return out;
}




void update_bs_gammas (vec &bs_gammas, const vec &gammas, const vec &gammasF1,const vec &alphas,
                       vec &W0H_bs_gammas, vec &W0h_bs_gammas, vec &W0H2_bs_gammas,
                       const vec &WH_gammas, const vec &Wh_gammas, const vec &WH2_gammas,
                       const vec &WlongH_alphas, const vec &Wlongh_alphas, const vec &WlongH2_alphas,
                       const vec &log_Pwk, const vec &log_Pwk2,
                       const uvec &indFast_H, const uvec &indFast_h,
                       const uvec &which_event, const uvec &which_right_event,
                       const uvec &which_left, const uvec &which_interval,
                       const bool &any_event, const bool &any_interval,
                       const field<vec> &prior_mean_bs_gammas, field<mat> &prior_Tau_bs_gammas,const vec &tau_bs_gammas,
                       const field<vec> &prior_mean_gammasF1, field<mat> &prior_Tau_gammasF1,const vec &tau_gammasF1,
                       const vec &prior_mean_gammas, mat &prior_Tau_gammas,
                       const vec &lambda_gammas, const double &tau_gammas, const bool &shrink_gammas,
                       const vec &prior_mean_alphas, mat &prior_Tau_alphas,
                       const vec &lambda_alphas, const double &tau_alphas, const bool &shrink_alphas,
                       vec &logLik_surv, double &denominator_surv, const uword &it,
                       /////
                         const mat &W0_H, const mat &W0_h, const mat &W0_H2,
                       vec &scale_bs_gammas, mat &acceptance_bs_gammas,
                       mat &res_bs_gammas,
                       const bool &recurrent,
                       const vec &frailtyH_sigmaF_alphaF, const vec &frailtyh_sigmaF_alphaF,
                       const vec &alphaF, const vec prior_mean_alphaF,
                       mat &prior_Tau_alphaF, const vec &lambda_alphaF,
                       const double &tau_alphaF, const bool &shrink_alphaF) {
  for (uword i = 0; i < bs_gammas.n_rows; ++i) {
    vec proposed_bs_gammas = propose_norm(bs_gammas, scale_bs_gammas, i);
    vec proposed_W0H_bs_gammas = W0_H * proposed_bs_gammas;
    vec proposed_W0h_bs_gammas(W0_h.n_rows);
    vec proposed_W0H2_bs_gammas(W0_H2.n_rows);
    if (any_event) {
      proposed_W0h_bs_gammas = W0_h * proposed_bs_gammas;
    }
    if (any_interval) {
      proposed_W0H2_bs_gammas = W0_H2 * proposed_bs_gammas;
    }
    
    /* if(i <2 || i > bs_gammas.n_rows - 3 ){
      if(it <2|| it == 500 ){  std::cout  << i <<" *** UPDATE BS GAMMAS i A L'iteration : "  << it << std::endl;}
      if(it <2|| it == 500 ){  std::cout  << i <<" bs_gammas"  << bs_gammas << std::endl;}
      if(it <2|| it == 500 ){  std::cout  << i <<" scale_bs_gammas"  << scale_bs_gammas << std::endl;}
      if(it <2|| it == 500 ){  std::cout  << i <<" proposed_bs_gammas"  << proposed_bs_gammas << std::endl;}   
      if(it <2|| it == 500 ){  std::cout  << i <<" W0_h \n"  << W0_h.head_rows(4) << std::endl;}
      if(it <2|| it == 500 ){  std::cout  << i <<" proposed_W0h_bs_gammas \n"  << proposed_W0h_bs_gammas.head_rows(4) << std::endl;}
    } */
      vec logLik_surv_proposed =
        log_surv(proposed_W0H_bs_gammas, proposed_W0h_bs_gammas, proposed_W0H2_bs_gammas,
                 WH_gammas, Wh_gammas, WH2_gammas,
                 WlongH_alphas, Wlongh_alphas, WlongH2_alphas,
                 log_Pwk, log_Pwk2, indFast_H, indFast_h,
                 which_event, which_right_event, which_left,
                 any_interval, which_interval,
                 recurrent, frailtyH_sigmaF_alphaF, frailtyh_sigmaF_alphaF);
      


    double numerator_surv =
        sum(logLik_surv_proposed) +
        logPrior_surv(proposed_bs_gammas, gammas, gammasF1, alphas, 
                      prior_mean_bs_gammas,prior_Tau_bs_gammas, tau_bs_gammas,
                      prior_mean_gammasF1,prior_Tau_gammasF1, tau_gammasF1,
                      prior_mean_gammas, prior_Tau_gammas, lambda_gammas, tau_gammas, shrink_gammas,
                      prior_mean_alphas, prior_Tau_alphas, lambda_alphas, tau_alphas, shrink_alphas,
                      recurrent, alphaF, prior_mean_alphaF, prior_Tau_alphaF,
                      lambda_alphaF, tau_alphaF, shrink_alphaF,it); 
      
      
      double log_ratio = numerator_surv - denominator_surv;
      if (std::isfinite(log_ratio) && exp(log_ratio) > R::runif(0.0, 1.0)) {
        bs_gammas = proposed_bs_gammas;
        W0H_bs_gammas = proposed_W0H_bs_gammas;
        if (any_event) {
          W0h_bs_gammas = proposed_W0h_bs_gammas;
        }
        if (any_interval) {
          W0H2_bs_gammas = proposed_W0H2_bs_gammas;
        }
        logLik_surv = logLik_surv_proposed;
        denominator_surv = numerator_surv;
        acceptance_bs_gammas.at(it, i) = 1;
      }
      if (it > 19) {
        scale_bs_gammas.at(i) =
          robbins_monro(scale_bs_gammas.at(i),
                        acceptance_bs_gammas.at(it, i), it);
      }
      res_bs_gammas.at(it, i) = bs_gammas.at(i);
  }
}


// [[Rcpp::export]]
vec rmvnorm2(int n, vec ev, mat evec) {
  int p = ev.n_elem;
  mat A = evec;
  
  mat B(1, p, fill::zeros); 
  
  for (int i = 0; i < p; ++i) {
    if (ev(i) > 0) {
      A.col(i) *= sqrt(ev(i));
    } else {
      A.col(i) *= 0;
    }
    B.col(i) = R::rnorm(0,1);
  } 
  
  mat X = A * B.t();
  
  return X;
}


void update_gammas (const vec &bs_gammas, vec &gammas,  vec &gammasF1,  const vec &alphas,
                    const vec &W0H_bs_gammas, const vec &W0h_bs_gammas, const vec &W0H2_bs_gammas,
                    vec &WH_gammas, vec &Wh_gammas, vec &WH2_gammas,
                    const vec &WlongH_alphas, const vec &Wlongh_alphas, const vec &WlongH2_alphas,
                    const vec &log_Pwk, const vec &log_Pwk2,
                    const uvec &indFast_H, const uvec &indFast_h,
                    const uvec &which_event, const uvec &which_right_event,
                    const uvec &which_left, const uvec &which_interval,
                    const bool &any_event, const bool &any_interval,
                    const field<vec> &prior_mean_bs_gammas, field<mat> &prior_Tau_bs_gammas,const vec &tau_bs_gammas,
                    const field<vec> &prior_mean_gammasF1, field<mat> &prior_Tau_gammasF1,const vec &tau_gammasF1,
                    const vec &prior_mean_gammas, mat &prior_Tau_gammas,
                    const vec &lambda_gammas, const double &tau_gammas, const bool &shrink_gammas,
                    const vec &prior_mean_alphas, mat &prior_Tau_alphas,
                    const vec &lambda_alphas, const double &tau_alphas, const bool &shrink_alphas,
                    vec &logLik_surv, double &denominator_surv, const uword &it,
                    /////
                      const mat &W_H, const mat &W_h, const mat &W_H2,
                      const mat &WF1_H, const mat &WF1_h,
                    double &scale_gammas, mat &acceptance_gammas, mat &res_gammas,
                    double &scale_gammasF1,  mat &acceptance_gammasF, mat &res_gammasF1, 

                    const bool &recurrent,
                    const vec &frailtyH_sigmaF_alphaF, const vec &frailtyh_sigmaF_alphaF,
                    const vec &alphaF, const vec prior_mean_alphaF,
                    mat &prior_Tau_alphaF, const vec &lambda_alphaF,
                    const double &tau_alphaF, const bool &shrink_alphaF,  const vec &ev, const mat &evec,  const vec &evF1, const mat &evecF1) {
   

    vec proposed_gammasF1= gammasF1 + rmvnorm2(1,evF1*scale_gammasF1,evecF1);
    vec proposed_gammas= gammas + rmvnorm2(1,ev*scale_gammas,evec);
    vec proposed_WH_gammas =  W_H * proposed_gammas + WF1_H*proposed_gammasF1; 
    vec proposed_Wh_gammas(W_h.n_rows);
    vec proposed_WH2_gammas(W_H2.n_rows);

    

    if (any_event) {
      proposed_Wh_gammas = W_h * proposed_gammas + WF1_h*proposed_gammasF1; 
    }

    if (any_interval) {
      proposed_WH2_gammas = W_H2 * proposed_gammas;
    }
      
    
    
    vec logLik_surv_proposed =
      log_surv(W0H_bs_gammas, W0h_bs_gammas, W0H2_bs_gammas,
               proposed_WH_gammas, proposed_Wh_gammas, proposed_WH2_gammas,
               WlongH_alphas, Wlongh_alphas, WlongH2_alphas,
               log_Pwk, log_Pwk2, indFast_H, indFast_h,
               which_event, which_right_event, which_left,
               any_interval, which_interval,
               recurrent, frailtyH_sigmaF_alphaF, frailtyh_sigmaF_alphaF);
      
    
    double numerator_surv =
      sum(logLik_surv_proposed) +
      logPrior_surv(bs_gammas, proposed_gammas, proposed_gammasF1,  alphas, 
                    prior_mean_bs_gammas,prior_Tau_bs_gammas, tau_bs_gammas,
                    prior_mean_gammasF1,prior_Tau_gammasF1, tau_gammasF1,
                    prior_mean_gammas, prior_Tau_gammas, lambda_gammas, tau_gammas, shrink_gammas,
                    prior_mean_alphas, prior_Tau_alphas, lambda_alphas, tau_alphas, shrink_alphas,
                    recurrent, alphaF, prior_mean_alphaF, prior_Tau_alphaF,
                    lambda_alphaF, tau_alphaF, shrink_alphaF,it);

    double log_ratio = numerator_surv - denominator_surv;
    
    if (std::isfinite(log_ratio) && exp(log_ratio) > R::runif(0.0, 1.0)) {
      gammas = proposed_gammas;
      gammasF1 = proposed_gammasF1;
      WH_gammas = proposed_WH_gammas;
      if (any_event) {
        Wh_gammas = proposed_Wh_gammas;
      }
      if (any_interval) {
        WH2_gammas = proposed_WH2_gammas;
      }
      logLik_surv = logLik_surv_proposed;
      denominator_surv = numerator_surv;
      acceptance_gammas.at(it, 0) = 1;
      acceptance_gammasF.at(it, 0) = 1;

    }
    

    
    if (it == 100 ||it == 200 ||it == 300 ||it == 400 ||it == 500 ||it == 600 ||it == 700 ||it == 800 ||it == 900 ||it == 1000 ||
        it == 1100 ||it == 1200 ||it == 1300 ||it == 1400 ||it == 1500 ||it == 1600 ||it == 1700 ||it == 1800 ||it == 1900 ||it == 2000 ||
        it == 2100 ||it == 2200 ||it == 2300 ||it == 2400 ||it == 2500 ||it == 2600 ||it == 2700 ||it == 2800 ||it == 2900 ||it == 3000 ) {
      if (mean(mean(acceptance_gammasF.rows(it-99,it))) > 0.3){scale_gammasF1 = scale_gammasF1 * (1 + 0.3);}
      if (mean(mean(acceptance_gammasF.rows(it-99,it))) < 0.15){scale_gammasF1 = scale_gammasF1 * (1 - 0.3);}
      if(scale_gammasF1 < 0.0001){scale_gammasF1 = 0.0001;}
      if(scale_gammasF1 > 5){scale_gammasF1 = 5;}

      if (mean(mean(acceptance_gammas.rows(it-99,it))) > 0.3){scale_gammas = scale_gammas * (1 + 0.3);}
      if (mean(mean(acceptance_gammas.rows(it-99,it))) < 0.15){scale_gammas = scale_gammas * (1 - 0.3);}
      if(scale_gammas < 0.0001){scale_gammas = 0.0001;}
      if(scale_gammas > 5){scale_gammas = 5;}
    }
// store results
    res_gammas.row(it) = gammas.t();
    res_gammasF1.row(it) = gammasF1.t();
          
}


void update_alphas (const vec &bs_gammas, const vec &gammas, const vec &gammasF1, vec &alphas,
                    const vec &W0H_bs_gammas, const vec &W0h_bs_gammas, const vec &W0H2_bs_gammas,
                    const vec &WH_gammas, const vec &Wh_gammas, const vec &WH2_gammas,
                    vec &WlongH_alphas, vec &Wlongh_alphas, vec &WlongH2_alphas,
                    const vec &log_Pwk, const vec &log_Pwk2,
                    const uvec &indFast_H, const uvec &indFast_h,
                    const uvec &which_event, const uvec &which_right_event,
                    const uvec &which_left, const uvec &which_interval,
                    const bool &any_event, const bool &any_interval,
                    const field<vec> &prior_mean_bs_gammas, field<mat> &prior_Tau_bs_gammas, const vec &tau_bs_gammas,
                    const field<vec> &prior_mean_gammasF1, field<mat> &prior_Tau_gammasF1,const vec &tau_gammasF1,
                    const vec &prior_mean_gammas, mat &prior_Tau_gammas,
                    const vec &lambda_gammas, const double &tau_gammas, const bool &shrink_gammas,
                    const vec &prior_mean_alphas, mat &prior_Tau_alphas,
                    const vec &lambda_alphas, const double &tau_alphas, const bool &shrink_alphas,
                    vec &logLik_surv, double &denominator_surv, const uword &it,
                    /////
                      const mat &Wlong_H, const mat &Wlong_h, const mat &Wlong_H2,
                    vec &scale_alphas, mat &acceptance_alphas, mat &res_alphas,
                    const bool &recurrent,
                    const vec &frailtyH_sigmaF_alphaF, const vec &frailtyh_sigmaF_alphaF,
                    const vec &alphaF, const vec prior_mean_alphaF,
                    mat &prior_Tau_alphaF, const vec &lambda_alphaF,
                    const double &tau_alphaF, const bool &shrink_alphaF) {
  for (uword i = 0; i < alphas.n_rows; ++i) {
    vec proposed_alphas = propose_norm(alphas, scale_alphas, i);
    vec proposed_WlongH_alphas = Wlong_H * proposed_alphas;
    vec proposed_Wlongh_alphas(Wlong_h.n_rows);
    if (any_event) {
      proposed_Wlongh_alphas = Wlong_h * proposed_alphas;
    }
    vec proposed_WlongH2_alphas(Wlong_H2.n_rows);
    if (any_interval) {
      proposed_WlongH2_alphas = Wlong_H2 * proposed_alphas;
    }
    vec logLik_surv_proposed =
      log_surv(W0H_bs_gammas, W0h_bs_gammas, W0H2_bs_gammas,
               WH_gammas, Wh_gammas, WH2_gammas,
               proposed_WlongH_alphas, proposed_Wlongh_alphas, proposed_WlongH2_alphas,
               log_Pwk, log_Pwk2, indFast_H, indFast_h,
               which_event, which_right_event, which_left,
               any_interval, which_interval,
               recurrent, frailtyH_sigmaF_alphaF, frailtyh_sigmaF_alphaF);
    
    
    
    double numerator_surv =
      sum(logLik_surv_proposed) +
      logPrior_surv(bs_gammas, gammas,gammasF1,  proposed_alphas, 
                    prior_mean_bs_gammas,prior_Tau_bs_gammas, tau_bs_gammas,
                    prior_mean_gammasF1,prior_Tau_gammasF1, tau_gammasF1,
                    prior_mean_gammas, prior_Tau_gammas, lambda_gammas, tau_gammas, shrink_gammas,
                    prior_mean_alphas, prior_Tau_alphas, lambda_alphas, tau_alphas, shrink_alphas,
                    recurrent, alphaF, prior_mean_alphaF, prior_Tau_alphaF,
                    lambda_alphaF, tau_alphaF, shrink_alphaF, it);
    
    double log_ratio = numerator_surv - denominator_surv;
    if (std::isfinite(log_ratio) && exp(log_ratio) > R::runif(0.0, 1.0)) {
      alphas = proposed_alphas;
      WlongH_alphas = proposed_WlongH_alphas;
      if (any_event) {
        Wlongh_alphas = proposed_Wlongh_alphas;
      }
      if (any_interval) {
        WlongH2_alphas = proposed_WlongH2_alphas;
      }
      logLik_surv = logLik_surv_proposed;
      denominator_surv = numerator_surv;
      acceptance_alphas.at(it, i) = 1;
    }
    if (it > 19) {
      scale_alphas.at(i) =
        robbins_monro(scale_alphas.at(i),
                      acceptance_alphas.at(it, i), it);
    }
    // store results
    res_alphas.at(it, i) = alphas.at(i);
  }
}

void update_alphaF (const vec &bs_gammas, const vec &gammas, const vec &gammasF1,const vec &alphas,
                    const vec &W0H_bs_gammas, const vec &W0h_bs_gammas, const vec &W0H2_bs_gammas,
                    const vec &WH_gammas, const vec &Wh_gammas, const vec &WH2_gammas,
                    const vec &WlongH_alphas, const vec &Wlongh_alphas, const vec &WlongH2_alphas,
                    const vec &log_Pwk, const vec &log_Pwk2,
                    const uvec &indFast_H, const uvec &indFast_h,
                    const uvec &which_event, const uvec &which_right_event,
                    const uvec &which_left, const uvec &which_interval,
                    const bool &any_event, const bool &any_interval,
                    const field<vec> &prior_mean_bs_gammas, field<mat> &prior_Tau_bs_gammas, const vec &tau_bs_gammas,
                    const field<vec> &prior_mean_gammasF1, field<mat> &prior_Tau_gammasF1, const vec &tau_gammasF1,

                    const vec &prior_mean_gammas, mat &prior_Tau_gammas,
                    const vec &lambda_gammas, const double &tau_gammas, const bool &shrink_gammas,
                    const vec &prior_mean_alphas, mat &prior_Tau_alphas,
                    const vec &lambda_alphas, const double &tau_alphas, const bool &shrink_alphas,
                    vec &logLik_surv, double &denominator_surv, const uword &it,
                    const mat &Wlong_H, const mat &Wlong_h, const mat &Wlong_H2,
                    //
                      const bool &recurrent,
                    const field<uvec> &which_term_H, const field<uvec> &which_term_h,
                    const vec &frailty_H, const vec &frailty_h,
                    vec &alphaF, vec &alphaF_H, vec &alphaF_h,
                    vec &scale_alphaF, mat &acceptance_alphaF, mat &res_alphaF,
                    const vec prior_mean_alphaF, mat &prior_Tau_alphaF,
                    const vec &lambda_alphaF, const double &tau_alphaF, 
                    const bool &shrink_alphaF,
                    const vec &sigmaF,
                    vec &frailtyH_sigmaF_alphaF, vec &frailtyh_sigmaF_alphaF) {
  for (uword i = 0; i < alphaF.n_rows; ++i) {
    vec proposed_alphaF = propose_norm(alphaF, scale_alphaF, i);
    vec proposed_alphaF_H(WH_gammas.n_rows, fill::ones);
    vec proposed_alphaF_h(Wh_gammas.n_rows, fill::ones);
    for (uword j = 0; j < alphaF.n_rows; ++j) {
      proposed_alphaF_H.rows(which_term_H.at(j)).fill(proposed_alphaF.at(j));
      proposed_alphaF_h.rows(which_term_h.at(j)).fill(proposed_alphaF.at(j));
    }
    vec proposed_frailtyH_sigmaF_alphaF(WH_gammas.n_rows, fill::zeros);
    vec proposed_frailtyh_sigmaF_alphaF(which_event.n_rows, fill::zeros);
    proposed_frailtyH_sigmaF_alphaF = frailty_H % proposed_alphaF_H * sigmaF;
    proposed_frailtyh_sigmaF_alphaF = frailty_h.rows(which_event) % proposed_alphaF_h.rows(which_event) * sigmaF;
    vec logLik_surv_proposed =
      log_surv(W0H_bs_gammas, W0h_bs_gammas, W0H2_bs_gammas,
               WH_gammas, Wh_gammas, WH2_gammas,
               WlongH_alphas, Wlongh_alphas, WlongH2_alphas,
               log_Pwk, log_Pwk2, indFast_H, indFast_h,
               which_event, which_right_event, which_left,
               any_interval, which_interval,
               recurrent, 
               proposed_frailtyH_sigmaF_alphaF, proposed_frailtyh_sigmaF_alphaF);
    double numerator_surv =
      sum(logLik_surv_proposed) +
      logPrior_surv(bs_gammas, gammas, gammasF1, alphas, 
                    prior_mean_bs_gammas,prior_Tau_bs_gammas, tau_bs_gammas,
                    prior_mean_gammasF1,prior_Tau_gammasF1, tau_gammasF1,
                    prior_mean_gammas, prior_Tau_gammas, lambda_gammas, tau_gammas, shrink_gammas,
                    prior_mean_alphas, prior_Tau_alphas, lambda_alphas, tau_alphas, shrink_alphas,
                    recurrent, proposed_alphaF, prior_mean_alphaF, prior_Tau_alphaF,
                    lambda_alphaF, tau_alphaF, shrink_alphaF, it);
    double log_ratio = numerator_surv - denominator_surv;
    if (std::isfinite(log_ratio) && exp(log_ratio) > R::runif(0.0, 1.0)) {
      alphaF = proposed_alphaF;
      alphaF_H = proposed_alphaF_H;
      alphaF_h = proposed_alphaF_h;
      logLik_surv = logLik_surv_proposed;
      denominator_surv = numerator_surv;
      acceptance_alphaF.at(it, i) = 1;
      frailtyH_sigmaF_alphaF = proposed_frailtyH_sigmaF_alphaF;
      frailtyh_sigmaF_alphaF = proposed_frailtyh_sigmaF_alphaF;
    }
    if (it > 19) {
      scale_alphaF.at(i) =
        robbins_monro(scale_alphaF.at(i),
                      acceptance_alphaF.at(it, i), it);
      
    }
    // store results
    res_alphaF.at(it, i) = alphaF.at(i);
  }
}

#endif
